import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { NgOptimizedImage } from '@angular/common';
@Component({
  selector: 'app-team-member',
  standalone: true,
  imports: [NgOptimizedImage],
  templateUrl: './team-member.component.html',
  styleUrl: './team-member.component.css'
})
export class TeamMemberComponent {
  @Input() name!: string;
  @Input() role!: string;
  @Input() bio!: string;
  @Input() imageUrl!: string;
}
