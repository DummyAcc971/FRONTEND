import { Injectable } from '@angular/core';
import { environment } from './environment';// Adjust the path as necessary
 
@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  getApiBaseUrl(): string {
    return environment.apiBaseUrl;
  }
 
  getLogoPath(): string {
    return `${environment.assetsPath}${environment.logoFileName}`;
  }
}
 