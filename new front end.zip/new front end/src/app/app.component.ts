import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common'; // Import CommonModule for ngIf, ngFor, etc.
import { FormsModule } from '@angular/forms';
import { DashboardComponent } from "./dashboard/dashboard.component"; // Import FormsModule for two-way data binding
import { HttpClientModule } from '@angular/common/http'; // Import HttpClientModule for HTTP requests
import { ReactiveFormsModule } from '@angular/forms';
import { StockChartComponent } from "./stock-chart/stock-chart.component";
import { DemoComponent } from './demo/demo.component';
import { SidebarComponent } from "./sidebar/sidebar.component";
import { SearchComponent } from "./search/search.component";
import { StocktableComponent } from "./stocktable/stocktable.component";
import { StockDetailsComponent } from "./stockdetails/stockdetails.component";
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, FormsModule, DashboardComponent, HttpClientModule, ReactiveFormsModule, DemoComponent, SidebarComponent, SearchComponent, StocktableComponent, StockDetailsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
 
})
export class AppComponent {
  title = 'my-angular-app';

  constructor(private translate: TranslateService) {
    this.translate.setDefaultLang('en');
    this.translate.use('en'); // Set the default language to English
  }

  
}
