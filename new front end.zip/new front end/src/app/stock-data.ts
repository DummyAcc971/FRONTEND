export interface StockData {
    datetime: string;
    price: number;
}
