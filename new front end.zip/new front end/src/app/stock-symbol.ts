export interface StockSymbol {
    symbol: string;
    description: string;
}
