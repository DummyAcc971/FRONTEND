import { Component } from '@angular/core';
import { TeamMemberComponent } from "../team-member/team-member.component";
import { VisionSectionComponent } from "../vision-section/vision-section.component";
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";

@Component({
  selector: 'app-title',
  standalone: true,
  imports: [TeamMemberComponent, VisionSectionComponent, HeaderComponent, FooterComponent],
  templateUrl: './title.component.html',
  styleUrl: './title.component.css'
})
export class TitleComponent {

}
