import { Component } from '@angular/core';

@Component({
  selector: 'app-searchresult',
  standalone: true,
  imports: [],
  templateUrl: './searchresult.component.html',
  styleUrl: './searchresult.component.css'
})
export class SearchresultComponent {

}
