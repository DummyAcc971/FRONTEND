import { Component } from '@angular/core';

@Component({
  selector: 'app-vision-section',
  standalone: true,
  imports: [],
  templateUrl: './vision-section.component.html',
  styleUrl: './vision-section.component.css'
})
export class VisionSectionComponent {

}
